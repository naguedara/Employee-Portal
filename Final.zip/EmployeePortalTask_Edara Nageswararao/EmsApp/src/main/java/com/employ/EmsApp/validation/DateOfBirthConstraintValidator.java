package com.employ.EmsApp.validation;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

public class DateOfBirthConstraintValidator  implements ConstraintValidator<DateOfBirth,String>{

	private Boolean notEmpty;
    private Integer min;
    private String birthValidation;
    private String emptyVal;

    @Override
    public void initialize(DateOfBirth field) {
    	birthValidation = field.message();
    	emptyVal = field.empty();
    }
	@Override
	public boolean isValid(String date, ConstraintValidatorContext context) {
	        if(date==null)
	        {
	        	context.buildConstraintViolationWithTemplate(emptyVal).addConstraintViolation();
	        	return false;
	        }
	        else
	        {
	        	DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
	        	System.out.println("date="+date);
	    		LocalDate dob = LocalDate.parse(date, formatter);
	    		LocalDate presentDate = LocalDate.now();
	    		LocalDate last20 = presentDate.minusYears(20);
	    		System.out.println("[dob]"+dob);
	    		System.out.println("[last20]"+last20);
	    		System.out.println("compare value="+dob.compareTo(last20));
	    		
	    		if(dob.compareTo(last20)>1)
	    		{
	    			context.buildConstraintViolationWithTemplate(birthValidation).addConstraintViolation();
		        	return false;
	    		}
	    		else
	    			return true;
	        }
	        	
	}

}
