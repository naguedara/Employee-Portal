package com.employ.EmsApp.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import com.employ.EmsApp.entity.EmployeeHistory;

public interface EmploymentHistoryRepository extends JpaRepository<EmployeeHistory, Integer> {
	
	
}
