package com.employ.EmsApp.validation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import javax.validation.Constraint;
import javax.validation.Payload;

@Constraint(validatedBy=NameConstraintValidator.class)
@Target({ElementType.METHOD,ElementType.FIELD})
@Retention(RetentionPolicy.RUNTIME)
public @interface NameField {
	public String value() default "";
	public String message() default "Please input alphabet only!!";
	public String empty() default "Input between 1 to 50 characters!!";
	public String lengthMsg() default "Input between 1 to 50 characters!!";
	public Class<?>[] groups() default {};
	public Class<? extends Payload>[] payload() default {};

}
