package com.employ.EmsApp.repo;

import java.math.BigInteger;
import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.employ.EmsApp.entity.Employee;

public interface EmployRepository extends JpaRepository<Employee, Integer> {
	
	
	@Query(value="select * from employees where last_name like %:firstName% or first_name like %:firstName% or gender=:gender or emp_id=:empId", nativeQuery=true)
	public List<Employee> getEmployeeBySearch(@Param("empId") Integer empId,@Param("gender") String gender,@Param("firstName") String firstName);
	
	@Query(value="select * from employees where last_name like %:firstName% or first_name like %:firstName% and gender=:gender order by first_name ASC , emp_id ASC", nativeQuery=true)
	public List<Employee> getEmployeeByGenderAndNameSearch(@Param("gender") String gender,@Param("firstName") String firstName);
	@Query(value="select * from employees where  gender=:gender order by first_name ASC , emp_id ASC", nativeQuery=true)
	public List<Employee> getEmployeeByGenderSearch(@Param("gender") String gender);

	@Query(value="select * from employees where  email_id=:email or office_mail=:email", nativeQuery=true)
	public List<Employee> getEmployeeByEmail(@Param("email") String mailId);
	
	@Query(value="select * from employees where  emp_id=:empId", nativeQuery=true)
	public Employee getEmployeeByEmpId(@Param("empId") Integer mailId);

		
}
