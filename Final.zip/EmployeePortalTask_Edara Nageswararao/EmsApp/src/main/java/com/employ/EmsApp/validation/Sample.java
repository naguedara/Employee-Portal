package com.employ.EmsApp.validation;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import org.springframework.util.SystemPropertyUtils;

public class Sample {
	public static void main(String[] args) {
		String date= "2020-09-09";
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
    	System.out.println("date="+date);
		LocalDate dob = LocalDate.parse(date, formatter);
		LocalDate presentDate = LocalDate.now();
		LocalDate last20 = presentDate.minusYears(20);
		System.out.println("[dob]"+dob);
		System.out.println("[last20]"+last20);
		System.out.println("compare value="+dob.compareTo(last20));
		 int diff = dob.compareTo(last20);
		 System.out.println(diff);
		 
		 
		 LocalDate today = LocalDate.now();
	        LocalDate anotherDay = LocalDate.of(2018, 01, 10);
	         
	        System.out.println(today.isEqual(anotherDay));      //false
	        System.out.println(today.isAfter(anotherDay));      //true
	        System.out.println(today.isBefore(anotherDay));     //false
	         
	         diff = anotherDay.compareTo(today);
	         System.out.println(diff);
			 
	}
}