package com.employ.EmsApp.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.StringTrimmerEditor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.supercsv.io.CsvBeanWriter;
import org.supercsv.io.ICsvBeanWriter;
import org.supercsv.prefs.CsvPreference;

import com.employ.EmsApp.entity.Employee;
import com.employ.EmsApp.entity.EmployeeHistory;
import com.employ.EmsApp.service.EmployeeService;

@Controller
@SessionAttributes("employObjList")
public class EmployeeControoller {
	@Autowired
	private EmployeeService employService;
	
	
	
	@InitBinder
	public void initBinder(WebDataBinder binder)
	{
		StringTrimmerEditor editor = new StringTrimmerEditor(true);
		binder.registerCustomEditor(String.class, editor);
	}

	@GetMapping("/")
	public String getEmployees()
	{
		System.out.println("hello");
		return "index";
	}
	@PostMapping("/addEmploy")
	public String addEmployee(Model model)
	{
		model.addAttribute("employee", new Employee());
		System.out.println("addEmployee ");
		List<Integer> list= new ArrayList<Integer>();
		model.addAttribute("allDepartments",list);
		return "register";
	}
	
	@PostMapping("/saveEmploy")
	public String saveEmploy(@Valid @ModelAttribute("employee") Employee emp,BindingResult bindingResult, Model model) throws ParseException
	{
		System.out.println("[emp]"+emp);
		System.out.println("[bindingResult]"+bindingResult);
		if(bindingResult.hasErrors())
			return "register";
		String dob =emp.getDateOfBirth();
		String doj = emp.getDateOfJoin();
		SimpleDateFormat formatter=new SimpleDateFormat("yyyy-MM-dd");
		if(dob!=null)
		{
			Date birth=formatter.parse(dob);  
			emp.setDob(birth);
		}
		if(doj!=null)
		{
			Date join=formatter.parse(doj);  
			
			emp.setDojDate(join);
		}
		
		employService.saveEmployee(emp);
		model.addAttribute("status", "Successfully Added/updated the Employee");
		return "register";
	}
	@GetMapping("/getAllEmployees")
	public String getAllEmployees(Model model,HttpSession session)
	{
		List<Employee> listEmp= employService.getEmployees();
		System.out.println("getAllEmployees= "+listEmp);
		session.setAttribute("employListObj", listEmp);
		model.addAttribute("listEmp", listEmp);
		return "index";
	}
	
	@RequestMapping(path="/deleteEmployee/{empId}")
	public String deleteEmployee(@PathVariable("empId") int emp,Model model)
	{
		System.out.println("deleteEmployee"+emp);
		employService.deleteEmploy(emp);
		List<Employee> listEmp= employService.getEmployees();
		System.out.println("getAllEmployees= "+listEmp);
		
		model.addAttribute("listEmp", listEmp);
		return "index";
	}
	@RequestMapping("/searchEmp")  
	public String searchEmpForm(Model model,@ModelAttribute("empSearch") Employee emp,HttpSession session)  
	{  
		System.out.println("emp ::"+emp);
		List<Employee> list = employService.searchEmpForm(emp);
		session.setAttribute("employListObj", list);
		model.addAttribute("listEmp", list);
		return "index";
	}  

	@RequestMapping("/editEmployee/{empId}")  
	public String editEmployee(@PathVariable("empId") int emp,Model model)  
	{  
		System.out.println("editEmpForm ::"+emp);
		
		Employee empObj = employService.getEmploye(emp);
		model.addAttribute("employee", empObj);
		model.addAttribute("emp", empObj);
		return "update";
	}  
	
	@RequestMapping("/csvDownLoad")  
	public String csvDownLoad(PrintWriter writer,Model model,HttpSession session,HttpServletResponse response) throws IOException  
	{  
		List<Employee> empListObj = (List<Employee>) session.getAttribute("employListObj");
		System.out.println("csvDownLoad ::"+empListObj);
		
		
		response.setContentType("text/csv");
		String fileName="employees"+System.currentTimeMillis()+".csv";
		String headerKey ="Content-Disposition";
		String headerValue = "attachment; filename="+fileName;
		response.setHeader(headerKey, headerValue);
		ICsvBeanWriter csvWriter = new CsvBeanWriter(response.getWriter(), CsvPreference.STANDARD_PREFERENCE);

        String[] csvHeader = {"Employee ID", "First Name", "Last Name", "Gender", "Date of Birth","PAN Card","Aadhaar Card Number","Mobile Number","Email Id",
        						"Office Email","Permanent Address","Present Address","Blood Group","Profile picture","Join Date","Employee Level",
        						"Post name","Basic Pay","House Allowance"};
        String[] nameMapping = {"empId", "firstName", "lastName", "gender", "dob","panNumber","aadhar","mobileNumber","emailId","officeEmail",
        							"permanentAddress","presentAddress","bloodGroup","profilePic","dojDate","empLevel","postName","basicPay","houseAllowance"};
        
        csvWriter.writeHeader(csvHeader);
        for(Employee emp:empListObj)
        {
        	csvWriter.write(emp, nameMapping);
        }
        csvWriter.close();       
		return "index";
	}  
	
	@RequestMapping(value="/employmentHistory/{empId}")
	public String employmentHistory(@PathVariable("empId") int emp,Model model)
	{
		System.out.println("[employmentHistory][starts]");
		List<EmployeeHistory> history = employService.getEmployeeHistory();
		model.addAttribute("history", history);
		Employee empObj = employService.getEmployee(emp);
		model.addAttribute("empName",empObj.getFirstName()+" "+empObj.getLastName()+"(#"+empObj.getEmpId()+")");
		return "employentHistory";
	}

}
