package com.employ.EmsApp.service;

import java.util.List;

import com.employ.EmsApp.entity.Employee;
import com.employ.EmsApp.entity.EmployeeHistory;

public interface EmployeeService {
	public List<Employee> getEmployees();

	public void deleteEmploy(int empId);

	public List<Employee> searchEmpForm(Employee emp);

	public void saveEmployee(Employee emp);

	public Employee getEmploye(int emp);

	public List<EmployeeHistory> getEmployeeHistory();

	public Employee getEmployee(int emp);

}
