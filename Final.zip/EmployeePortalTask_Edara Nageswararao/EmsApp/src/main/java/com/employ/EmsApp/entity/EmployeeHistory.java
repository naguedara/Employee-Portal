package com.employ.EmsApp.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.Range;
import com.employ.EmsApp.validation.AadhaarNumber;
import com.employ.EmsApp.validation.BloodGroup;
import com.employ.EmsApp.validation.DateOfBirth;
import com.employ.EmsApp.validation.EmailValidation;
import com.employ.EmsApp.validation.EmployeeNumber;
import com.employ.EmsApp.validation.GenderValidation;
import com.employ.EmsApp.validation.PostValidation;
import com.employ.EmsApp.validation.NameField;
import com.employ.EmsApp.validation.PANNumberValidation;
import com.employ.EmsApp.validation.PhoneValidation;
import com.employ.EmsApp.validation.PostLevel;


@Entity
@Table(name="employment_history")
public class EmployeeHistory {
	@Id
	@Column(name="id")
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer id;
	
	@Column(name="emp_id")
	private Integer empId;
	@Column(name="organization_name")
	private String organizationName;
	
	@Column(name="from_date")
	private Date fromDate;
	
	@Column(name="until_date")
	private Date untilDate;
	
	@Column(name="location")
	private String location; 
	
	@Column(name="country")
	private String country;
	
	@Column(name="post")
	private String post;
	
	@Column(name="skill_used")
	private String skills;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getEmpId() {
		return empId;
	}

	public void setEmpId(Integer empId) {
		this.empId = empId;
	}

	public String getOrganizationName() {
		return organizationName;
	}

	public void setOrganizationName(String organizationName) {
		this.organizationName = organizationName;
	}

	public Date getFromDate() {
		return fromDate;
	}

	public void setFromDate(Date fromDate) {
		this.fromDate = fromDate;
	}

	public Date getUntilDate() {
		return untilDate;
	}

	public void setUntilDate(Date untilDate) {
		this.untilDate = untilDate;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getPost() {
		return post;
	}

	public void setPost(String post) {
		this.post = post;
	}

	public String getSkills() {
		return skills;
	}

	public void setSkills(String skills) {
		this.skills = skills;
	}

	@Override
	public String toString() {
		return "EmployeeHistory [id=" + id + ", empId=" + empId + ", organizationName=" + organizationName
				+ ", fromDate=" + fromDate + ", untilDate=" + untilDate + ", location=" + location + ", country="
				+ country + ", post=" + post + ", skills=" + skills + "]";
	}
	
		
}
