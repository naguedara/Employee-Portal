package com.employ.EmsApp.validation;

import java.util.ArrayList;
import java.util.List;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

public class PostLevelConstraintValidator implements ConstraintValidator<PostLevel,Integer>{

	private String theNameVal;
	@Override
	public void initialize(PostLevel theName)
	{
		theNameVal = theName.value();
	}
	@Override
	public boolean isValid(Integer theName, ConstraintValidatorContext theConstraintValidatorContext) {
		System.out.println("is valid executed ="+theName);
		if(theName!=null)
		{
			List<Integer> groups = new ArrayList<Integer>();
			for(int i=7;i<14;i++)
			{
				groups.add(i);
			}
			if(!groups.contains(theName))
				return false;
			else
				return true;
			
		}
		else
		{
			theConstraintValidatorContext.buildConstraintViolationWithTemplate("It should not empty");
			return false;
		}
	}

}
