package com.employ.EmsApp.validation;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

public class GenderConstraintValidator implements ConstraintValidator<GenderValidation,String>{

	private String theNameVal;
	@Override
	public void initialize(GenderValidation theName)
	{
		theNameVal = theName.value();
	}
	@Override
	public boolean isValid(String theName, ConstraintValidatorContext theConstraintValidatorContext) {
		System.out.println("is valid executed ="+theName);
		if(theName!=null)
		{
			if(theName.startsWith("F")||theName.startsWith("M")||theName.startsWith("ND"))
				return true;
			else
				return false;
			
		}
		else
		{
			theConstraintValidatorContext.buildConstraintViolationWithTemplate("It should not empty");
			return false;
		}
	}

}
