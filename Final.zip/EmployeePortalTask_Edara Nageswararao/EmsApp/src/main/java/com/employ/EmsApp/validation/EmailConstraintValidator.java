package com.employ.EmsApp.validation;

import java.util.List;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import org.springframework.beans.factory.annotation.Autowired;

import com.employ.EmsApp.entity.Employee;
import com.employ.EmsApp.repo.EmployRepository;

public class EmailConstraintValidator implements ConstraintValidator<EmailValidation,String>{

	@Autowired
	private EmployRepository employRepo;
	private String avail;
	private String value;
	private String invalid;
	private String message;
	private String emptyVal;
	@Override
	public void initialize(EmailValidation theName)
	{
		avail = theName.alreadyAvail();
		emptyVal = theName.emptyVal();
		invalid = theName.emailValid();
		//lengthVal= theName.lengthMsg();
		message = theName.message();
	}
	@Override
	public boolean isValid(String theName, ConstraintValidatorContext context) {
		System.out.println("Email name is valid executed ="+theName);
        context.disableDefaultConstraintViolation();
        if (theName==null) {
        	System.out.println("Email  is empty");
            context.buildConstraintViolationWithTemplate(invalid).addConstraintViolation();
            return false;
        }
        else if(ValidationUtil.validateEmail(theName)==false)
        {
        	System.out.println("first name  validation length");
        	 context.buildConstraintViolationWithTemplate(invalid).addConstraintViolation();
	            return false;
        }
        else{
        	System.out.println("email avail validation ::"+theName);
        	System.out.println("email employRepo ::"+employRepo);
        	if(employRepo==null)
        		return true;
        	List<Employee> emailList =employRepo.getEmployeeByEmail(theName);
        	System.out.println("email avail validation1 ::"+emailList.size());
        	if(!emailList.isEmpty())
        	{
        		context.buildConstraintViolationWithTemplate(avail).addConstraintViolation();
        		return false;
        	}
        	else 
        		return true;
        }
    }

}
