package com.employ.EmsApp.validation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import javax.validation.Constraint;
import javax.validation.Payload;

@Constraint(validatedBy=PostValidationConstraintValidator.class)
@Target({ElementType.METHOD,ElementType.FIELD})
@Retention(RetentionPolicy.RUNTIME)
public @interface PostValidation {
	public String value() default "";
	public String message() default "Please input only alphabet and space";
	public String empty() default "is required";
	public String lengthMsg() default "Please input within 30 characters";
	public Class<?>[] groups() default {};
	public Class<? extends Payload>[] payload() default {};
}
