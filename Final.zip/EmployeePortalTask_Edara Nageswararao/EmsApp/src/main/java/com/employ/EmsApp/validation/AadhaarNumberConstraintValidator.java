package com.employ.EmsApp.validation;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

public class AadhaarNumberConstraintValidator  implements ConstraintValidator<AadhaarNumber,String>{

	private Boolean notEmpty;
    private Integer min;
    private String lengthMsg;
    private String invalidPan;
    private String emptyVal;
    private String messageLength;

    @Override
    public void initialize(AadhaarNumber field) {
    	lengthMsg = field.lengthMsg();
    	invalidPan = field.message();
    	emptyVal = field.empty();
    }
	@Override
	public boolean isValid(String value, ConstraintValidatorContext context) {
		System.out.println("Aadhaar number is valid executed ="+value);
	        context.disableDefaultConstraintViolation();
	        if (value==null) {
	        	System.out.println("Aadhaar number is null");
	            context.buildConstraintViolationWithTemplate(lengthMsg).addConstraintViolation();
	            return false;
	        }
	        else if(value.length()!=12)
	        {
	        	System.out.println("Aadhaar number  validation length");
	        	 context.buildConstraintViolationWithTemplate(lengthMsg).addConstraintViolation();
		            return false;
	        }
	        else{
	        	boolean allLetters = value.chars().allMatch(Character::isDigit);
	        	if(allLetters==false)
	        	{
	        		 context.buildConstraintViolationWithTemplate(invalidPan).addConstraintViolation();
			            return false;
	        	}
	        	else
	        		return true;
	        }
	    }

}
