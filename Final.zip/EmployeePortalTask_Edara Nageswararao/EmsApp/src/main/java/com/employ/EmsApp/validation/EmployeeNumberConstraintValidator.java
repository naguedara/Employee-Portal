package com.employ.EmsApp.validation;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import org.springframework.beans.factory.annotation.Autowired;

import com.employ.EmsApp.entity.Employee;
import com.employ.EmsApp.repo.EmployRepository;

public class EmployeeNumberConstraintValidator implements ConstraintValidator<EmployeeNumber, Integer>{
	
	private String emptyVal;
	private String messageLength;
	private String avail;
	
	@Autowired
	private EmployRepository employRepo;

	@Override
	public void initialize(EmployeeNumber field) {
		messageLength = field.message();
		//emptyVal = field.empty();
		avail=field.alreadyAVail();
	}
	@Override
	public boolean isValid(Integer empId, ConstraintValidatorContext context) {
		// TODO Auto-generated method stub
		System.out.println("[Employee number]"+empId);
		if(empId==null)
		{
			System.out.println("[address][null]");
			context.buildConstraintViolationWithTemplate(messageLength).addConstraintViolation();
			return false;
		}
		else
		{
			if(employRepo==null)
				return true;
			Employee emp = employRepo.getEmployeeByEmpId(empId);
			System.out.println("emp obj::"+emp);
			if(emp==null)
				return true;
			
			else
			{
				context.buildConstraintViolationWithTemplate(avail).addConstraintViolation();
				return false;
			}
		}
		
	}

}
