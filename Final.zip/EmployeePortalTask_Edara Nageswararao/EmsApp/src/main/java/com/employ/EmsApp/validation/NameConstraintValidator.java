package com.employ.EmsApp.validation;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

public class NameConstraintValidator implements ConstraintValidator<NameField,String>{

	private String theNameVal;
	private String emptyVal;
	private String lengthVal;
	private String message;
	@Override
	public void initialize(NameField theName)
	{
		theNameVal = theName.value();
		emptyVal = theName.empty();
		lengthVal= theName.lengthMsg();
		message = theName.message();
	}
	@Override
	public boolean isValid(String theName, ConstraintValidatorContext context) {
		System.out.println("first name is valid executed ="+theName);
        context.disableDefaultConstraintViolation();
        if (theName==null) {
        	System.out.println("first name ada");
            context.buildConstraintViolationWithTemplate(emptyVal).addConstraintViolation();
            return false;
        }
        else if(!(theName.length()<50&&theName.length()>1))
        {
        	System.out.println("first name  validation length");
        	 context.buildConstraintViolationWithTemplate(lengthVal).addConstraintViolation();
	            return false;
        }
        else if (ValidationUtil.isStringOnlyAlphabet(theName)==false) {
        	System.out.println("alphabets");
            context.buildConstraintViolationWithTemplate(message).addConstraintViolation();
            return false;
        }
        return true;
    }

}
