package com.employ.EmsApp.validation;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

public class PostValidationConstraintValidator implements ConstraintValidator<PostValidation, String> {

	private Boolean notEmpty;
	private Integer min;
	private String lengthMsg;
	private String invalidPost;
	private String emptyVal;
	private String messageLength;

	@Override
	public void initialize(PostValidation field) {
		lengthMsg = field.lengthMsg();
		invalidPost = field.message();
		emptyVal = field.empty();
	}

	@Override
	public boolean isValid(String value, ConstraintValidatorContext context) {
		System.out.println("House Allowance is valid executed =" + value);
		context.disableDefaultConstraintViolation();
		if (value == null) {
			System.out.println("post is validation");
			context.buildConstraintViolationWithTemplate(emptyVal).addConstraintViolation();
			return false;
		} else if (value.length() > 30) {
			System.out.println("post is validation length");
			context.buildConstraintViolationWithTemplate(lengthMsg).addConstraintViolation();
			return false;
		}

		else {
			boolean status = ValidationUtil.validatePost(value);
			if (status == false) {
				System.out.println("Post is validation length");
				context.buildConstraintViolationWithTemplate(invalidPost).addConstraintViolation();
				return false;
			}
			return true;
		}

	}

}
