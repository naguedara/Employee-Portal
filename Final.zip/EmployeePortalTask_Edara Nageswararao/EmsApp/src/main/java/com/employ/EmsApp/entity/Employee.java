package com.employ.EmsApp.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.Range;
import com.employ.EmsApp.validation.AadhaarNumber;
import com.employ.EmsApp.validation.BloodGroup;
import com.employ.EmsApp.validation.DateOfBirth;
import com.employ.EmsApp.validation.EmailValidation;
import com.employ.EmsApp.validation.EmployeeNumber;
import com.employ.EmsApp.validation.GenderValidation;
import com.employ.EmsApp.validation.PostValidation;
import com.employ.EmsApp.validation.NameField;
import com.employ.EmsApp.validation.PANNumberValidation;
import com.employ.EmsApp.validation.PhoneValidation;
import com.employ.EmsApp.validation.PostLevel;


@Entity
@Table(name="employees")
public class Employee {
	@Id
	@Column(name="emp_id")
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@EmployeeNumber
	private Integer empId;
	@NameField
	@Column(name="first_name")
	private String firstName;
	@Column(name="last_name")
	@NameField
	private String lastName;
	@GenderValidation
	@Column(name="gender")
	private String gender; 
	
	@Column(name="dob")
	private Date dob;
	@PANNumberValidation
	@Column(name="pan_num")
	private String panNumber;
	@AadhaarNumber
	@Column(name="aadhaar_num")
	private String aadhar;
	@PhoneValidation
	@Column(name="mobile_num")
	private String mobileNumber;
	@EmailValidation
	@Column(name="email_id")
	private String emailId;
	@EmailValidation
	@Column(name="office_mail")
	private String officeEmail;
	@NotNull(message="Text should not exceeds 200 characters!")
	@Size(max=200,message="Text should not exceeds 200 characters!")
	@Column(name="permanent_address")
	private String permanentAddress;
	@NotNull(message="Text should not exceeds 200 characters!")
	@Size(max=200,message="Text should not exceeds 200 characters!")
	@Column(name="present_address")
	private String presentAddress;
	@BloodGroup
	@Column(name="blood_group")
	private String bloodGroup;
	@Column(name="profile_pict")
	private String profilePic;
	@Column(name="doj")
	private Date dojDate;
	@PostLevel
	@Column(name="emp_level")
	private int empLevel;
	@PostValidation
	@Column(name="post_name")
	private String postName;
	@Range(min = 100, max = 99999999,message="Please input  between 3 to 8 characters!") 
	@NotNull(message="Please input  between 3 to 8 characters!")
	@Column(name="basic_pay")
	private int basicPay;
	@Range(min = 100, max = 99999,message="Please input  between 3 to 5  characters!!") 
	@NotNull(message="Please input  between 3 to 5  characters!!")
	@Column(name="house_allowance")
	private Integer houseAllowance;
	@Transient
	//@NotNull(message="Please input valid date in dd/mm/yyyy format")
	//@DateOfBirth
	private String dateOfBirth;
	@Transient
	//@NotNull(message="Please input valid date in dd/mm/yyyy format")
	private String dateOfJoin;
	
	public String getDateOfBirth() {
		return dateOfBirth;
	}
	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	public String getDateOfJoin() {
		return dateOfJoin;
	}
	public void setDateOfJoin(String dateOfJoin) {
		this.dateOfJoin = dateOfJoin;
	}
	public Integer getEmpId() {
		return empId;
	}
	public void setEmpId(Integer empId) {
		this.empId = empId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public Date getDob() {
		return dob;
	}
	public void setDob(Date dob) {
		this.dob = dob;
	}
	public String getPanNumber() {
		return panNumber;
	}
	public void setPanNumber(String panNumber) {
		this.panNumber = panNumber;
	}
	public String getAadhar() {
		return aadhar;
	}
	public void setAadhar(String aadhar) {
		this.aadhar = aadhar;
	}
	
	public String getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public String getOfficeEmail() {
		return officeEmail;
	}
	public void setOfficeEmail(String officeEmail) {
		this.officeEmail = officeEmail;
	}
	public String getPermanentAddress() {
		return permanentAddress;
	}
	public void setPermanentAddress(String permanentAddress) {
		this.permanentAddress = permanentAddress;
	}
	public String getPresentAddress() {
		return presentAddress;
	}
	public void setPresentAddress(String presentAddress) {
		this.presentAddress = presentAddress;
	}
	public String getBloodGroup() {
		return bloodGroup;
	}
	public void setBloodGroup(String bloodGroup) {
		this.bloodGroup = bloodGroup;
	}
	public String getProfilePic() {
		return profilePic;
	}
	public void setProfilePic(String profilePic) {
		this.profilePic = profilePic;
	}
	public Date getDojDate() {
		return dojDate;
	}
	public void setDojDate(Date dojDate) {
		this.dojDate = dojDate;
	}
	public int getEmpLevel() {
		return empLevel;
	}
	public void setEmpLevel(int empLevel) {
		this.empLevel = empLevel;
	}
	public String getPostName() {
		return postName;
	}
	public void setPostName(String postName) {
		this.postName = postName;
	}
	public int getBasicPay() {
		return basicPay;
	}
	public void setBasicPay(int basicPay) {
		this.basicPay = basicPay;
	}
	
	public Integer getHouseAllowance() {
		return houseAllowance;
	}
	public void setHouseAllowance(Integer houseAllowance) {
		this.houseAllowance = houseAllowance;
	}
	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", firstName=" + firstName + ", lastName=" + lastName + ", gender=" + gender
				+ ", dob=" + dob + ", panNumber=" + panNumber + ", aadhar=" + aadhar + ", mobileNumber=" + mobileNumber
				+ ", emailId=" + emailId + ", officeEmail=" + officeEmail + ", permanentAddress=" + permanentAddress
				+ ", presentAddress=" + presentAddress + ", bloodGroup=" + bloodGroup + ", profilePic=" + profilePic
				+ ", dojDate=" + dojDate + ", empLevel=" + empLevel + ", postName=" + postName + ", basicPay="
				+ basicPay + ", houseAllowance=" + houseAllowance + ", dateOfBirth=" + dateOfBirth + ", dateOfJoin="
				+ dateOfJoin + "]";
	}
	

	
}
