package com.employ.EmsApp.validation;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

public class PhoneNumberConstraintValidator implements ConstraintValidator<PhoneValidation,String>{

	private String theNameVal;
	private String emptyVal;
	private String lengthVal;
	private String message;
	@Override
	public void initialize(PhoneValidation theName)
	{
		theNameVal = theName.value();
		emptyVal = theName.empty();
		lengthVal= theName.lengthMsg();
		message = theName.message();
	}
	@Override
	public boolean isValid(String theName, ConstraintValidatorContext context) {
		System.out.println("Phone number is valid executed ="+theName);
        context.disableDefaultConstraintViolation();
        if (theName==null) {
            context.buildConstraintViolationWithTemplate(emptyVal).addConstraintViolation();
            return false;
        }
        else if (ValidationUtil.isStringOnlyNumeric(theName)==false) {
            context.buildConstraintViolationWithTemplate(message).addConstraintViolation();
            return false;
        }
        else if(theName.length()!=10)
        {
        	 context.buildConstraintViolationWithTemplate(lengthVal).addConstraintViolation();
	            return false;
        }
      
        return true;
    }

}
