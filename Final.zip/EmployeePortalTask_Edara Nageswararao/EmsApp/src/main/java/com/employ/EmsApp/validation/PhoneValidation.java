package com.employ.EmsApp.validation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import javax.validation.Constraint;
import javax.validation.Payload;

@Constraint(validatedBy=PhoneNumberConstraintValidator.class)
@Target({ElementType.METHOD,ElementType.FIELD})
@Retention(RetentionPolicy.RUNTIME)
public @interface PhoneValidation {
	public String value() default "";
	public String message() default "Please input numeric only!!";
	public String lengthMsg() default "Please input 10 numbers only!";
	public String empty() default "is required";
	public String onlyNumeric() default "Please input numeric only!";
	public Class<?>[] groups() default {};
	public Class<? extends Payload>[] payload() default {};

}
