package com.employ.EmsApp.validation;

import java.util.ArrayList;
import java.util.List;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

public class BloodGroupConstraintValidator implements ConstraintValidator<BloodGroup,String>{

	private String theNameVal;
	@Override
	public void initialize(BloodGroup theName)
	{
		theNameVal = theName.value();
	}
	@Override
	public boolean isValid(String theName, ConstraintValidatorContext theConstraintValidatorContext) {
		System.out.println("is valid executed ="+theName);
		if(theName!=null)
		{
			List<String> groups = new ArrayList<String>();
			groups.add("A+");
			groups.add("A-");
			groups.add("B+");
			groups.add("B-");
			groups.add("AB+");
			groups.add("AB-");
			if(!groups.contains(theName))
				return false;
			else
				return true;
			
		}
		else
		{
			theConstraintValidatorContext.buildConstraintViolationWithTemplate("It should not empty");
			return false;
		}
	}

}
