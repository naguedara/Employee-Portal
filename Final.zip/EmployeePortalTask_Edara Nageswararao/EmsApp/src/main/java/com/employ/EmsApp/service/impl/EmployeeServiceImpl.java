package com.employ.EmsApp.service.impl;

import java.util.ArrayList;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.yaml.snakeyaml.events.Event.ID;

import com.employ.EmsApp.entity.Employee;
import com.employ.EmsApp.entity.EmployeeHistory;
import com.employ.EmsApp.repo.EmployRepository;
import com.employ.EmsApp.repo.EmploymentHistoryRepository;
import com.employ.EmsApp.service.EmployeeService;

@Service
public class EmployeeServiceImpl implements EmployeeService{
	
	@Autowired
	private EmployRepository employeeRepo;
	@Autowired
	private EntityManager entityManager;
	
	@Autowired
	private EmploymentHistoryRepository employmentHistoryRepo;
	
	@Override
	public List<Employee> getEmployees() {
		// TODO Auto-generated method stub 
		return employeeRepo.findAll();
	}
	@Override
	public void deleteEmploy(int empId) {
		// TODO Auto-generated method stub
		employeeRepo.deleteById(empId);
	}
	@Override
	public List<Employee> searchEmpForm(Employee emp) {
		// TODO Auto-generated method stub
		if(emp.getEmpId()!=null&&emp.getFirstName()==null&&emp.getGender()==null)
		{
			List<Employee> empList = new ArrayList<Employee>();
			Session session = entityManager.unwrap(Session.class);
			Employee empObj = session.get(Employee.class,emp.getEmpId());
			if(empObj!=null)
				empList.add(empObj);
			return empList;
		}
		else if(emp.getEmpId()==null&&emp.getFirstName()!=null&&emp.getGender()!=null)
		{
			//List<Employee> empList = new ArrayList<Employee>();
			List<Employee> empList = employeeRepo.getEmployeeByGenderAndNameSearch(emp.getGender(),emp.getFirstName());
			return empList;
		}
		else if(emp.getEmpId()==null&&emp.getFirstName()==null&&emp.getGender()!=null)
		{
			//List<Employee> empList = new ArrayList<Employee>();
			List<Employee> empList = employeeRepo.getEmployeeByGenderSearch(emp.getGender());
			return empList;
		}
		else
		{
		List<Employee> empList = employeeRepo.getEmployeeBySearch(emp.getEmpId(), emp.getGender(),emp.getFirstName());
		System.out.println("[empList]"+empList);
		return empList;
		}
	}
	@Override
	public void saveEmployee(Employee emp) {
		System.out.println("[save employee]"+emp);
		employeeRepo.save(emp);
		
	}
	@Override
	public Employee getEmploye(int emp) {
		// TODO Auto-generated method stub
		return employeeRepo.findById(emp).get();
	}
	@Override
	public List<EmployeeHistory> getEmployeeHistory() {
		// TODO Auto-generated method stub
		return employmentHistoryRepo.findAll();
	}
	@Override
	public Employee getEmployee(int emp) {
		// TODO Auto-generated method stub
		return employeeRepo.findById(emp).get();
	}

}
