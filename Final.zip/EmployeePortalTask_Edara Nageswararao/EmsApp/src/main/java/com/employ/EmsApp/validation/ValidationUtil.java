package com.employ.EmsApp.validation;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ValidationUtil {
	 public static boolean isStringOnlyAlphabet(String str) 
	    { 
	        return str.matches("^[a-zA-Z]*$"); 
	    } 
	 public static boolean isStringOnlyNumeric(String str) 
	    { 
	        return ((str != null) 
	                && (!str.equals("")) 
	                && (str.matches("^[0-9]*$"))); 
	    } 

	 public static boolean validateEmail(String email) 
		{
			String regex = "^[\\w!#$%&'*+/=?`{|}~^-]+(?:\\.[\\w!#$%&'*+/=?`{|}~^-]+)*@(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,6}$";
			 
			Pattern pattern = Pattern.compile(regex);
			Matcher matcher = pattern.matcher(email);
			System.out.println(email +" : "+ matcher.matches());
			return matcher.matches();
		}
	 public static boolean validatePost(String post)
	 {
		 String regex = "^[a-zA-Z ]*$";
		 if(post.matches(regex))
			 return true;
		 else
			 return false;
	 }
	 public static boolean validatePAN(String pan)
	 {
		 String regex = "^[a-zA-Z0-9]*$";
		 if(pan.matches(regex))
			 return true;
		 else
			 return false;
	 }
}
