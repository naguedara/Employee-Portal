package com.employ.EmsApp.validation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import javax.validation.Constraint;
import javax.validation.Payload;

@Constraint(validatedBy=DateOfBirthConstraintValidator.class)
@Target({ElementType.METHOD,ElementType.FIELD})
@Retention(RetentionPolicy.RUNTIME)
public @interface DateOfBirth {
	public String value() default "";
	public String message() default "Please  enter a valid date , age must be >=20";
	public String empty() default "Please input valid date in dd/mm/yyyy format";
	//public String lengthMsg() default "Please input 12 numbers only!";
	public Class<?>[] groups() default {};
	public Class<? extends Payload>[] payload() default {};
}
