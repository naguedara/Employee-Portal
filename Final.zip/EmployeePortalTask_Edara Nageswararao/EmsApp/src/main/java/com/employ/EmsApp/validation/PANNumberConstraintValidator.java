package com.employ.EmsApp.validation;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

public class PANNumberConstraintValidator  implements ConstraintValidator<PANNumberValidation,String>{

	private Boolean notEmpty;
    private Integer min;
    private String lengthMsg;
    private String invalidPan;
    private String emptyVal;
    private String messageLength;

    @Override
    public void initialize(PANNumberValidation field) {
    	lengthMsg = field.lengthMsg();
    	invalidPan = field.message();
    	emptyVal = field.empty();
    }
	@Override
	public boolean isValid(String value, ConstraintValidatorContext context) {
		System.out.println("PAN number is valid executed ="+value);
	        context.disableDefaultConstraintViolation();
	        if (value==null) {
	        	System.out.println("PAN validation");
	            context.buildConstraintViolationWithTemplate(lengthMsg).addConstraintViolation();
	            return false;
	        }
	        else if(value.length()!=10)
	        {
	        	System.out.println("PAN validation length");
	        	 context.buildConstraintViolationWithTemplate(lengthMsg).addConstraintViolation();
		            return false;
	        }
	        else{
	        	boolean allLetters = ValidationUtil.validatePAN(value);
	        	System.out.println("all letters ::"+allLetters);
	        	if(allLetters==false)
	        	{
	        		 context.buildConstraintViolationWithTemplate(invalidPan).addConstraintViolation();
			            return false;
	        	}
	        	else
	        		return true;
	        }
	    }

}
