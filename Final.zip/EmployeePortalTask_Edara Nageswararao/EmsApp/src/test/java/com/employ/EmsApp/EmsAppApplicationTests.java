package com.employ.EmsApp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
class EmsAppApplicationTests {

	public static void main(String[] args) throws Exception {
		SpringApplication.run(EmsAppApplicationTests.class, args);
		
	}


}
